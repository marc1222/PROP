public class Posicion {
    public int x;
    public int y;

    Posicion() {

    }
    Posicion(int x, int y) {
        this.x = x;
        this.y = y;
    }
}