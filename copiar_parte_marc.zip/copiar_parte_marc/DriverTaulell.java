import java.io.File;
import java.util.ArrayList;
import java.util.Scanner;

public class DriverTaulell {
    //Aquest Driver de taulell està pensat per donat un problema inicial hardcoded,
    //afegir / borrar tantes peces com es vulguin ja sigui per teclat o un fitxer de text
    //tot parametritat en variables declarades a l'inici de la funcio MAIN
    //i a posteriori comprovar tantes regles d'integritat del tauler com es vulguin cridant els respectius mètodes
    //a mes entre check i check podem anar fent moviments interactius de peces
//---------------OPCIONS---------------------
    //1 -afegir -> funcio privada crea_peca
    //2 -borrar -> funcio privada borra_peca
    //3 -moure -> funcio privada mou_peca
    //4 -imprimir todos_movimientos
    //5 -comprovar situació d'escac i mat per qualsevol color

    public static void main(String[] args) {
        //init taulell amb un problema
        Taulell Master = init_taulell();
        Master.printTauler();
        //creem peces
        int num_crear = 3;  //si es fa interactiu s'ha d'actualitzar el fitxer en cas que es varii el nombre
        int num_borrar = 3; //si es fa interactiu s'ha d'actualitzar el fitxer en cas que es varii el nombre
        int num_movs = 4; //si es fa interactiu s'ha d'actualitzar el fitxer en cas que es varii el nombre

        //String file_path = "./files/interactive_taulell.txt";
        String file_path = "./files/interactive_taulell3.txt";
        File file = new File(file_path);
        try {
            Scanner scM = new Scanner(file);
            //Scanner scM = new Scanner(System.in);
            int ch = 0;
            int opcio;
            do {
                ch++;
                if (ch == 8) scM = new Scanner(System.in);

                System.out.println("Introdueix una opció:");
                System.out.println("(1)Crear (2)Borrar (3)Moure (4)all movs (5)escac i mat (6) Print amenaces");
                opcio = scM.nextInt();
                System.out.print(opcio);
                if (opcio > 0 && opcio < 7) {
                    switch (opcio) {
                        case 1:
                            //crear peca
                            crea_peca(Master, scM);
                            break;
                        case 2:
                            //borra peca
                            borra_peca(Master,scM);
                            break;
                        case 3:
                            //mou peca
                            mou_peca(Master,scM);
                            break;
                        case 4:
                            //todos movimientos
                            all_movs(Master,scM);
                            break;
                        case 5:
                            //jaque mate
                            check_mate(Master,scM);
                            break;
                        case 6:
                            //imprimir amenaces
                            print_amenaca(Master);
                            break;
                    }
                    Master.printTauler();
                }

            } while(true);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private static Taulell init_taulell() {
        Problema p = new Problema ();//"8/8/8/5K2/5p2/4k3/1Q6/5R2 w - - 0 0"
        p.crear_problema(2, "5K2/8/8/8/8/8/8/5k2 w - - 0 0");
        Taulell T = new Taulell(p.getPeces());
        T = new Taulell(T);
        System.out.println("\nTaulell init ok\n");
        return T;
    }
    private static void crea_peca(Taulell T,Scanner sc) {
        System.out.println("\nIntrodueix la posició a on vols crear la peça (x,y)");
        int x = sc.nextInt();
        int y = sc.nextInt();
        System.out.println("\nIntrodueix el color de la peça (W (0) - B (1))");
        int color = sc.nextInt();
        System.out.println("\nIntrodueix el tipus de la peça");
        sc.nextLine();
        String type = sc.nextLine();
        T.crear_peça(new Posicion(x,y), color, type);

    }
    private static void borra_peca(Taulell T,Scanner sc) {
        System.out.println("\nIntrodueix la posició a on vols BORRAR la peça (x,y)");
        int x = sc.nextInt();
        int y = sc.nextInt();
        T.destrueix_peça(new Posicion(x,y));
    }
    private static void mou_peca(Taulell T,Scanner sc) {
        System.out.println("\nIntrodueix la posició de la peça a moure(x0,y0)");
        int x0 = sc.nextInt();
        int y0 = sc.nextInt();
        System.out.println("\nIntrodueix el destí de la peça (x,y)");
        int x = sc.nextInt();
        int y = sc.nextInt();
        System.out.println("\nIntrodueix el color de la peça (W (0) - B (1))");
        int color = sc.nextInt();
        boolean ret = T.mover_pieza(new Posicion(x0,y0),new Posicion(x,y),color);
        System.out.println((ret)?"\nmov VALID":("\nmov NOOO VALID"));
    }
    private static void all_movs(Taulell T, Scanner sc) {
        System.out.println("\nIntrodueix la peça sobre la qual vols veure els seus movs (x,y)");
        int x = sc.nextInt();
        int y = sc.nextInt();
        Posicion[] p = T.todos_movimientos(new Posicion(x,y));
        System.out.print("Valid movs: ");
        for (int i = 0; i < p.length; ++i) {
            System.out.print("["+i+"] --> ("+p[i].x+","+p[i].y+")    ");
            if (i%4 == 3) System.out.println("");
        }
        System.out.println();

    }
    private static void check_mate(Taulell T, Scanner sc) {
        System.out.println("Recorda que el rei HA D'EXISTIR");
        System.out.println("\nIntrodueix el color W (0) - B (1)");
        int color = sc.nextInt();
        int aux = T.escac_i_mat(color);
        if (aux == 1) {
            System.out.println("--- ESCAC I MAT---");
        }
        else if (aux == 0) {
            System.out.println("--- ESCAC---");

        }
        else if (aux == 2) {
            System.out.println("--- REI OFEGAT---");
        }
        else { //-1
            System.out.println("---REI VIVITO Y COLEANDO---");
        }
    }
    private static void print_amenaca(Taulell T) {
        Peca aux;
        ArrayList<Posicion> aux2;
        for (int i = 0; i < 8; ++i) {
            for (int j = 0; j < 8; ++j) {
                aux = T.getPecaPosició(new Posicion(i,j));
                if (aux.getTipus() !=  define.PECA_NULA) {
                    System.out.println("Peça: "+aux.getTipus()+"  Color: "+aux.getColor());
                    System.out.println("Posició-> X: "+i+" Y: "+j);
                    System.out.print("Amenaçes (x,y): ");
                    aux2 = aux.getAmenaces();
                    for (int k = 0; k < aux2.size(); ++k) {
                        System.out.print("("+aux2.get(k).x+","+aux2.get(k).y+") ");
                    }
                    System.out.println();
                    System.out.print("Amenaçades (x,y): ");
                    aux2 = aux.getAmenacades();
                    for (int k = 0; k < aux2.size(); ++k) {
                        System.out.print("("+aux2.get(k).x+","+aux2.get(k).y+") ");
                    }
                    System.out.println();
                }
            }
        }
    }
}
