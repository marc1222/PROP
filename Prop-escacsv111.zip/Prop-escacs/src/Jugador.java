import java.util.ArrayList;
import java.util.Scanner;
import java.io.*;
// Import the IOException class to handle errors
// Import the FileWriter class

/**
 * @author Marian Dumitru Danci
 */
public abstract class Jugador {
    public abstract long moviment(Posicion inici, Posicion fi);

    public abstract int getTipus();
    /*
    public abstract boolean iniciarSessio();
    public abstract public boolean resigstrar();
    */
}