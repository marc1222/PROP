public class prova {
    public static void main(String [] args)
    {
        double dist = Math.sqrt(7*7+0*0);
        if (dist == (int)dist) {
            System.out.println("TREUEEEUUEUEUE MSKSJKKKK");
        }
        else System.out.println("FALSEEEEEEEEEE PARGUELONCIO");
    }
}
